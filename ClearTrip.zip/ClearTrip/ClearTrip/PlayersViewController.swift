//
//  PlayersViewController.swift
//  ClearTrip
//
//  Created by heena thapar on 14/10/23.
//

import UIKit

class PlayerCell: UITableViewCell {
    @IBOutlet weak var playerNameLbl: UILabel!
    @IBOutlet weak var scoreLbl: UILabel!
    @IBOutlet weak var playerImage: UIImageView!
    
   
}

class PlayersViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    var matchVM: MatchViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        matchVM = MatchViewModel()
        
    }
    
    func configTableView(){
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(, forCellReuseIdentifier: "cell")
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.matchVM.getAllPlayersScores()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
    }

}

