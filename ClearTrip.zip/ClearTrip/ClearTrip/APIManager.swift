//
//  APIManager.swift
//  ClearTrip
//
//  Created by heena thapar on 14/10/23.
//

import Foundation

class APIManager {
    
    func getAllMatchesData(completion: @escaping (_ matches: [MatchModel]?, _ message: String?) -> Void){
        
        let url = URL(string: "https://api.npoint.io/bc3f07c7442e85446788")!
        let urlRequest = URLRequest(url: url)
        
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            DispatchQueue.main.async {
                guard error == nil else {
                    print("Error")
                    completion(nil, error?.localizedDescription ?? "Unable to fetch Matches")
                    return
                }
                if let data = data {
                    let matchs = try? JSONDecoder().decode([MatchModel].self, from: data)
                    print(matchs)
                    completion(matchs, nil)
                }
               
            }
        }.resume()
    }
}
