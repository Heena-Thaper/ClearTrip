//
//  MatchModel.swift
//  ClearTrip
//
//  Created by heena thapar on 14/10/23.
//

import Foundation

struct MatchModel: Decodable {
    var match: Int
    var player1: PlayerModel!
    var player2: PlayerModel!
}
