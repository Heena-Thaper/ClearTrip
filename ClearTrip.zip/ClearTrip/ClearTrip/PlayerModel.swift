//
//  PlayerModel.swift
//  ClearTrip
//
//  Created by heena thapar on 14/10/23.
//

import Foundation

struct PlayerModel: Decodable {
    var id: Int!
    var score: Int!
}
