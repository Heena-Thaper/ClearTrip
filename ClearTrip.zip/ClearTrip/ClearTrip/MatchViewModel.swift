//
//  MatchViewModel.swift
//  ClearTrip
//
//  Created by heena thapar on 14/10/23.
//

import Foundation

class MatchViewModel {
    
    var matches = [MatchModel]()
    var players = [Int: Int]() // ["id": "Score"]
    
    init() {
        // For Fetching the data from As api get more time load or unresponsive sometime i used local josn file to fetch the data
        
//        APIManager().getAllMatchesData { matches, message in
//            guard  message == nil else {
//                return
//            }
//            guard let matches = matches else {
//                return
//            }
//            self.matches = matches
//            self.getAllPlayersScores()
//        }
//
        // Get the data from json file
        getMatchesFromFile()
    }
    
    func getAllPlayersScores() -> [Int: Int]{
        
        for match in matches {
            let player1Id = match.player1.id ?? 0
            let player2Id = match.player2.id ?? 0
            
            var player1Score = 0
            var player2Score = 0
            
            if match.player1.score > match.player2.score {
                player1Score = 3
                player2Score = 0
            }else if match.player1.score == match.player2.score {
                player1Score = 1
                player2Score = 1
            }else{
                player1Score = 0
                player2Score = 3
            }
            
           
            if  let score = players[player1Id] {
                players[player1Id] = score + player1Score
            }else{
                players[player1Id] = player1Score
            }
            
            if let score = players[player2Id] {
                players[player2Id] = score + player2Score
            }else{
                players[player2Id] =  player2Score
            }
            
            print(players)
            
        }
        
        print(players)
        return players
        
    }
    
    func getMatchesFromFile() {
        guard let filePath = Bundle.main.url(forResource: "Matches", withExtension: "json") else{
            print("Unable to get json file ")
            return
        }
        
        guard let data = try? Data(contentsOf: filePath )else {
            print("Unable to get Data")
            return
        }
        guard let matches = try?  JSONDecoder().decode([MatchModel].self, from: data) else {
            print("Unable to Decode")
            return
        }
        self.matches = matches
    }
    
}
